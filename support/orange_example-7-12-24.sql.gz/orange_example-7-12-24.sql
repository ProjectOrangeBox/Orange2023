# ************************************************************
# Sequel Ace SQL dump
# Version 20067
#
# https://sequel-ace.com/
# https://github.com/Sequel-Ace/Sequel-Ace
#
# Host: 127.0.0.1 (MySQL 5.7.39)
# Database: orange_example
# Generation Time: 2024-07-13 01:49:26 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE='NO_AUTO_VALUE_ON_ZERO', SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table auth
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth`;

CREATE TABLE `auth` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table childern
# ------------------------------------------------------------

DROP TABLE IF EXISTS `childern`;

CREATE TABLE `childern` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL,
  `firstname` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table config
# ------------------------------------------------------------

DROP TABLE IF EXISTS `config`;

CREATE TABLE `config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(64) NOT NULL,
  `key` varchar(32) NOT NULL,
  `value` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_on` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;

INSERT INTO `config` (`id`, `filename`, `key`, `value`, `is_active`, `created_on`, `updated_on`)
VALUES
	(1,'foobar','foo','bar',1,'2024-01-19 10:39:04',NULL),
	(2,'foobar','bar','foo',1,'2024-01-19 10:39:13',NULL),
	(3,'color','red','true',1,'2024-01-19 10:39:25',NULL),
	(4,'color','blue','false',1,'2024-01-19 10:39:31',NULL),
	(5,'user','position','Cookie Tester',1,'2024-01-19 11:49:14','2024-01-19 12:04:14');

/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table language
# ------------------------------------------------------------

DROP TABLE IF EXISTS `language`;

CREATE TABLE `language` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang` varchar(8) NOT NULL,
  `filename` varchar(32) NOT NULL,
  `key` varchar(32) NOT NULL,
  `value` varchar(512) NOT NULL,
  `is_active` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table orange_permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `orange_permissions`;

CREATE TABLE `orange_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `description` varchar(512) NOT NULL,
  `group` varchar(128) NOT NULL,
  `migration` varchar(128) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_key` (`key`) USING BTREE,
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `orange_permissions` WRITE;
/*!40000 ALTER TABLE `orange_permissions` DISABLE KEYS */;

INSERT INTO `orange_permissions` (`id`, `key`, `description`, `group`, `migration`, `is_active`)
VALUES
	(1,'uri://open/file','Open File','File',NULL,1),
	(2,'uri://close/file','Close File','File',NULL,1),
	(3,'uri://delete/file','Delete File','File',NULL,0);

/*!40000 ALTER TABLE `orange_permissions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table orange_role_permission
# ------------------------------------------------------------

DROP TABLE IF EXISTS `orange_role_permission`;

CREATE TABLE `orange_role_permission` (
  `role_id` int(10) unsigned NOT NULL DEFAULT '0',
  `permission_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_id`,`permission_id`),
  UNIQUE KEY `role_id` (`role_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `orange_role_permission` WRITE;
/*!40000 ALTER TABLE `orange_role_permission` DISABLE KEYS */;

INSERT INTO `orange_role_permission` (`role_id`, `permission_id`)
VALUES
	(1,1),
	(1,2),
	(1,3);

/*!40000 ALTER TABLE `orange_role_permission` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table orange_roles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `orange_roles`;

CREATE TABLE `orange_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` varchar(512) NOT NULL,
  `migration` varchar(128) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `idx_name` (`name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `orange_roles` WRITE;
/*!40000 ALTER TABLE `orange_roles` DISABLE KEYS */;

INSERT INTO `orange_roles` (`id`, `name`, `description`, `migration`, `is_active`)
VALUES
	(1,'admin','Adminstrator',NULL,1),
	(2,'guest','Guest',NULL,1);

/*!40000 ALTER TABLE `orange_roles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table orange_user_meta
# ------------------------------------------------------------

DROP TABLE IF EXISTS `orange_user_meta`;

CREATE TABLE `orange_user_meta` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(32) DEFAULT NULL,
  `ext` varchar(10) DEFAULT NULL,
  `dashboard_url` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `orange_user_meta` WRITE;
/*!40000 ALTER TABLE `orange_user_meta` DISABLE KEYS */;

INSERT INTO `orange_user_meta` (`id`, `phone`, `ext`, `dashboard_url`)
VALUES
	(1,'123-123-1234','x23','/admin/dashboard'),
	(2,'333-333-4444','559','/admin/accounting');

/*!40000 ALTER TABLE `orange_user_meta` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table orange_user_role
# ------------------------------------------------------------

DROP TABLE IF EXISTS `orange_user_role`;

CREATE TABLE `orange_user_role` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `role_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`role_id`),
  UNIQUE KEY `user_id` (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `orange_user_role` WRITE;
/*!40000 ALTER TABLE `orange_user_role` DISABLE KEYS */;

INSERT INTO `orange_user_role` (`user_id`, `role_id`)
VALUES
	(1,1);

/*!40000 ALTER TABLE `orange_user_role` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table orange_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `orange_users`;

CREATE TABLE `orange_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_email_unique` (`email`) USING BTREE,
  KEY `idx_email` (`email`) USING BTREE,
  KEY `idx_password` (`password`) USING BTREE,
  KEY `idx_username` (`username`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `orange_users` WRITE;
/*!40000 ALTER TABLE `orange_users` DISABLE KEYS */;

INSERT INTO `orange_users` (`id`, `username`, `email`, `password`, `is_active`, `is_deleted`)
VALUES
	(1,'dmyers','donmyers@foobar.com','$2y$10$0Q52TZjCYHJVv/AQkl2ExuWbqhRXzityT4mcDeZ.pM7k7HUCbOpo.',1,0),
	(2,'guest','guest@example.com','$2y$10$nCXIFgZav1/FzIKgsJ2lWuj.l.NCLXCOwcagzy.T.7uzowZ2pqAIO',1,0);

/*!40000 ALTER TABLE `orange_users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table people
# ------------------------------------------------------------

DROP TABLE IF EXISTS `people`;

CREATE TABLE `people` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;

INSERT INTO `people` (`id`, `firstname`, `lastname`, `age`)
VALUES
	(2,'Charlie','Brown',22),
	(5,'Jane','Vine',23),
	(6,'Jay','Lines',88),
	(7,'Johnny','Appleseed',25),
	(11,'Jenny','Pancake',32),
	(12,'John','Myers',25),
	(16,'Dr','Pepper',37),
	(20,'Joe','Coffee',45),
	(21,'Jenny','Jones',23),
	(22,'Frank','Wrong',46),
	(27,'Dr','Pepper',88),
	(30,'Jesse','James',48),
	(31,'Fred','Rubble',66),
	(32,'testing','testing',23);

/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table phinxlog
# ------------------------------------------------------------

DROP TABLE IF EXISTS `phinxlog`;

CREATE TABLE `phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `phinxlog` WRITE;
/*!40000 ALTER TABLE `phinxlog` DISABLE KEYS */;

INSERT INTO `phinxlog` (`version`, `migration_name`, `start_time`, `end_time`, `breakpoint`)
VALUES
	(20231010183304,'Init','2023-10-10 18:43:07','2023-10-10 18:43:08',0);

/*!40000 ALTER TABLE `phinxlog` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table snippets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `snippets`;

CREATE TABLE `snippets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `value` text,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
